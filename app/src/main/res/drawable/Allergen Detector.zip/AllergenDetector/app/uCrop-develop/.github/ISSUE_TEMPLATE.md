**Do you want to request a *feature* or report a *bug*?**

**What is the current behavior?**

**What is the expected behavior?**

**If the current behavior is a bug, please provide the steps to reproduce and if possible a minimal demo of the problem.**

**Please attach any *image files*, *URL* and `stack trace` that can be used to reproduce the *bug*.**

**Which versions of uCrop, and which Android API versions are affected by this issue? Did this work in previous versions of uCrop?**